# Wep Application Microservice

Microservice is a single-page web application designed to control the process of collecting and processing data to monitor the health condition of the patient.

