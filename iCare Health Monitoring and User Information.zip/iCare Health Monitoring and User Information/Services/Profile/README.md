# Profile Service

Profile microservice is designed to manage and store user profiles.

## Author

[Yury Aslamov](https://aslamovyura.github.io/)