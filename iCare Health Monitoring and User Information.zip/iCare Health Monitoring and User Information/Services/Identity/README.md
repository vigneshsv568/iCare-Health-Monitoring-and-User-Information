# Identity Service

Identity microservice is designed to control access to application resources.

## Author

[Yury Aslamov](https://aslamovyura.github.io/)