# Sensor service

Sensor microservice is designed to manage and store information about telemetry sensors and patient health data, collected by sensors.

## Author

[Yury Aslamov](https://aslamovyura.github.io/)