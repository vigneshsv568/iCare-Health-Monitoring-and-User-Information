# Report Service

Report microservice is designed to manage and store patient health reports, received from DataProcessor microservice.

## Author

[Yury Aslamov](https://aslamovyura.github.io/)