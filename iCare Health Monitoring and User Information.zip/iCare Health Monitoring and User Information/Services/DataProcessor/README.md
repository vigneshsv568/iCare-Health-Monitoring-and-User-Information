# DataProcessor Service

DataProcessor microservice is designed to process data received from telemetry sensors.

