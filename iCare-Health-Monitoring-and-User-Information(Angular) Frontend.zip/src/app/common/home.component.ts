import { Component } from '@angular/core';

@Component({
    selector: 'home-app',
    template: '<h1>iCare health monitoring service</h1>'
})
export class HomeComponent { }