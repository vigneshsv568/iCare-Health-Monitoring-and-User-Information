import { Component } from '@angular/core';

@Component({
    selector: 'not-found-app',
    template: '<h1>Page was not found</h1>'
})
export class NotFoundComponent { }