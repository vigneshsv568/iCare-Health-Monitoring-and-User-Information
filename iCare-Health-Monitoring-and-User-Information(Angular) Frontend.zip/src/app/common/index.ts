export * from './nav.component';
export * from './home.component';
export * from './not-found.component';
export * from './footer.component';