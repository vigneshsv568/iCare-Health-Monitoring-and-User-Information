export class Profile {
    id: string;
    accountId: string;
    firstName: string;
    lastName: string;
    middleName: string;
    birthDate: Date;
    gender: string;
    height: number;
    weight: number;
}