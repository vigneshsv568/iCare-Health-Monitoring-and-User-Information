export class Sensor {
    id: number;
    serial: string;
    sensorType: string;
    profileId: string;
}