export class User {
    id: string;
    username: string;
    role: string;
    token: string;
}