export class HealthCheck {
    service: string;
    url: string;
    status: string;
}