import { Component } from '@angular/core';
     
@Component({
    selector: 'icare-app',
    templateUrl: './app.component.html',
    styleUrls: ['../styles.css']
})
export class AppComponent { }