

## Getting Started

Install required packages:

```
> npm install
```

To run application, type the following command from the application root directory:

```
> ng serve --open
```

